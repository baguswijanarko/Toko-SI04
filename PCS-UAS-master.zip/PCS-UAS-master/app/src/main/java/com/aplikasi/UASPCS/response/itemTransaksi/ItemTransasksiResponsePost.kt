package com.aplikasi.UASPCS.response.itemTransaksi

data class ItemTransasksiResponsePost(
    val `data`: Data,
    val message: String,
    val success: Boolean
)
