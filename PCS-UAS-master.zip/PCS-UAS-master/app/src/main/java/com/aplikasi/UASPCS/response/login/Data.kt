package com.aplikasi.UASPCS.response.login

data class Data(
    val admin: Admin,
    val token: String
)