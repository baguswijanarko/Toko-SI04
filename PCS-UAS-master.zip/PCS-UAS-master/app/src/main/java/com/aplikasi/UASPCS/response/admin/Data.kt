package com.aplikasi.UASPCS.response.admin

data class Data(
    val admin: Admin
)