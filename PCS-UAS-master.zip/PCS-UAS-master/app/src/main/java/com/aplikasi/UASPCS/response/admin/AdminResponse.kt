package com.aplikasi.UASPCS.response.admin

data class AdminResponse(
    val `data`: Data,
    val message: String,
    val success: Boolean
)